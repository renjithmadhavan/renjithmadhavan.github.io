
## Testing Matplotlib with examples


```python
%matplotlib inline
```


```python
import numpy as np
import matplotlib.pyplot as plt
```


```python
mu, sigma = 100, 15
data_set = mu + sigma * np.random.randn(10000)
```


```python
data_set[1:10]
```




    array([ 116.85585425,  121.9697522 ,   92.85314344,  125.35052732,
            103.40217907,   68.23504822,  105.87907472,   99.97717637,
            103.90885799])




```python
n, bins, patches = plt.hist(data_set, 50, normed=1, facecolor='g', alpha=0.75)
plt.xlabel('Smarts')
plt.ylabel('Probability')
plt.title('Histogram of IQ')
plt.text(60, .025, r'$\mu=100,\ \sigma=15$')
plt.axis([40, 160, 0, 0.03])
plt.grid(True)
plt.show()
```


![png](output_5_0.png)



```python

```
